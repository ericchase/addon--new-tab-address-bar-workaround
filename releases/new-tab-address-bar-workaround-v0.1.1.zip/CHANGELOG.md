## v0.1.1

Added uuid to manifest.

## v0.1

Simple event listening extension.
