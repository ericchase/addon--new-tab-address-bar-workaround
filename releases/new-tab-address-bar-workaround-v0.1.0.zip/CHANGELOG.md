## v0.1

Simple event listening extension.
